"""Dataset-free expanded gate for the scalar coverage-state level set.

The gate has two deliberately separate layers:

* a complete 16-case x 2-resolution x 3-seed geometry/representation matrix;
* a small 3-objective x 3-seed, three-update computational matrix.

The second layer is only a code learnability and early-gradient check.  It is
not a performance experiment and it never reads D_R, D_V, or D_T.
"""

from __future__ import annotations

from collections import deque
from copy import deepcopy
from dataclasses import dataclass, replace
from math import isfinite

import torch
from torch import Tensor

from ..cache.schema import stable_fingerprint
from ..coverage_state_batches import (
    CoverageStateFusedBatch,
    CoverageStateNaturalTrainBatch,
    CoverageStatePairTrainBatch,
)
from ..coverage_state_level_set import (
    CURELiteCoverageStateLevelSet,
    CoverageStateLevelSetConfig,
    normalize_cslf_feature,
    truncated_signed_distance_field,
)
from ..coverage_state_observability import (
    changed_feature_cells,
    occupancy_to_phase_grid,
    occupancy_to_scalar_grid,
    structural_output_support,
    target_response_support,
)
from ..coverage_state_sobolev import (
    CoverageStateAbsoluteTargets,
    CoverageStatePairTargets,
    CoverageStateSobolevConfig,
    prepare_coverage_state_focused_absolute_targets,
    prepare_coverage_state_pair_targets,
)
from ..train.coverage_state_fused_step import (
    CoverageStatePairObjective,
    coverage_state_fused_train_step,
)
from .coverage_state_training import coverage_state_model_fingerprint


COVERAGE_STATE_DATASET_FREE_SCHEMA = (
    "cure-lite-cslf-expanded-dataset-free-gate-v1"
)
COVERAGE_STATE_DATASET_FREE_CASES = (
    "one_pixel_target",
    "three_pixel_compact_target",
    "two_disconnected_targets",
    "target_at_image_edge",
    "target_near_invalid_barrier",
    "empty_state",
    "single_false_negative_island",
    "multiple_false_islands",
    "component_null_deletion",
    "identity_null",
    "same_feature_cell_multiple_occupancy_phases",
    "full_grid_deletion_hidden_by_scalar_projection",
    "clean_pair_with_natural_miss_already_present",
    "clutter_feature_peak_without_target",
    "low_rms_feature",
    "high_dynamic_range_feature",
)
COVERAGE_STATE_DATASET_FREE_SIZES = (64, 256)
COVERAGE_STATE_DATASET_FREE_SEEDS = (42, 43, 44)
COVERAGE_STATE_DATASET_FREE_TRAINING_UPDATES = 3
COVERAGE_STATE_DATASET_FREE_STRIDE = 4
COVERAGE_STATE_DATASET_FREE_FEATURE_CHANNELS = 2
COVERAGE_STATE_DATASET_FREE_WIDTH = 4


@dataclass(frozen=True)
class CoverageStateDatasetFreeCaseResult:
    case_name: str
    size: int
    seed: int
    state_type: str
    pair_kind: str | None
    optimizer_eligible_pair: bool
    expected_scalar_hidden: bool
    target_pixels_plus: int
    target_pixels_minus: int
    target_zero_level_exact: bool
    target_fields_finite: bool
    model_fields_finite: bool
    hard_union_exact: bool
    scalar_visible: bool | None
    phase_visible: bool | None
    phase_roundtrip_exact: bool | None
    target_response_pixels: int
    target_response_outside_scalar_rf_pixels: int
    target_response_outside_phase_rf_pixels: int
    predicted_negative_pixels: int
    predicted_negative_components: int
    identity_field_exact: bool | None
    hidden_component_field_exact: bool | None
    component_new_negative_pixels: int | None
    component_new_negative_components: int | None

    def canonical_payload(self) -> dict[str, object]:
        return {
            "case_name": self.case_name,
            "size": self.size,
            "seed": self.seed,
            "state_type": self.state_type,
            "pair_kind": self.pair_kind,
            "optimizer_eligible_pair": self.optimizer_eligible_pair,
            "expected_scalar_hidden": self.expected_scalar_hidden,
            "target_pixels_plus": self.target_pixels_plus,
            "target_pixels_minus": self.target_pixels_minus,
            "target_zero_level_exact": self.target_zero_level_exact,
            "target_fields_finite": self.target_fields_finite,
            "model_fields_finite": self.model_fields_finite,
            "hard_union_exact": self.hard_union_exact,
            "scalar_visible": self.scalar_visible,
            "phase_visible": self.phase_visible,
            "phase_roundtrip_exact": self.phase_roundtrip_exact,
            "target_response_pixels": self.target_response_pixels,
            "target_response_outside_scalar_rf_pixels": (
                self.target_response_outside_scalar_rf_pixels
            ),
            "target_response_outside_phase_rf_pixels": (
                self.target_response_outside_phase_rf_pixels
            ),
            "predicted_negative_pixels": self.predicted_negative_pixels,
            "predicted_negative_components": (
                self.predicted_negative_components
            ),
            "identity_field_exact": self.identity_field_exact,
            "hidden_component_field_exact": (
                self.hidden_component_field_exact
            ),
            "component_new_negative_pixels": (
                self.component_new_negative_pixels
            ),
            "component_new_negative_components": (
                self.component_new_negative_components
            ),
        }


@dataclass(frozen=True)
class CoverageStateDatasetFreeTrainingResult:
    seed: int
    objective: str
    updates: int
    forward_calls: int
    backward_calls: int
    optimizer_steps: int
    logical_state_evaluations: int
    initial_model_fingerprint: str
    final_model_fingerprint: str
    selection_fingerprint: str
    first_nonzero_gradient_update: tuple[tuple[str, int], ...]
    factual_miss_target_pixels: int
    factual_no_miss_target_pixels: int
    losses_finite: bool
    parameters_changed: bool
    diagnostic_fields_finite: bool
    identity_field_exact: bool
    hidden_component_field_exact: bool
    component_new_negative_pixels: int
    component_new_negative_components: int
    empty_negative_pixels: int
    empty_negative_components: int
    hard_union_exact: bool

    def canonical_payload(self) -> dict[str, object]:
        return {
            "seed": self.seed,
            "objective": self.objective,
            "updates": self.updates,
            "forward_calls": self.forward_calls,
            "backward_calls": self.backward_calls,
            "optimizer_steps": self.optimizer_steps,
            "logical_state_evaluations": self.logical_state_evaluations,
            "initial_model_fingerprint": self.initial_model_fingerprint,
            "final_model_fingerprint": self.final_model_fingerprint,
            "selection_fingerprint": self.selection_fingerprint,
            "first_nonzero_gradient_update": {
                name: update
                for name, update in self.first_nonzero_gradient_update
            },
            "factual_miss_target_pixels": self.factual_miss_target_pixels,
            "factual_no_miss_target_pixels": (
                self.factual_no_miss_target_pixels
            ),
            "losses_finite": self.losses_finite,
            "parameters_changed": self.parameters_changed,
            "diagnostic_fields_finite": self.diagnostic_fields_finite,
            "identity_field_exact": self.identity_field_exact,
            "hidden_component_field_exact": (
                self.hidden_component_field_exact
            ),
            "component_new_negative_pixels": (
                self.component_new_negative_pixels
            ),
            "component_new_negative_components": (
                self.component_new_negative_components
            ),
            "empty_negative_pixels": self.empty_negative_pixels,
            "empty_negative_components": self.empty_negative_components,
            "hard_union_exact": self.hard_union_exact,
        }


@dataclass(frozen=True)
class CoverageStateDatasetFreeReceipt:
    case_results: tuple[CoverageStateDatasetFreeCaseResult, ...]
    training_results: tuple[CoverageStateDatasetFreeTrainingResult, ...]
    checks: tuple[tuple[str, bool], ...]
    D_R_accessed: bool = False
    D_V_accessed: bool = False
    D_T_accessed: bool = False
    performance_claim_supported: bool = False

    def __post_init__(self) -> None:
        self.verify()

    def verify(self) -> None:
        """Fail closed on incomplete evidence, scope drift, or check drift."""

        if (
            not isinstance(self.case_results, tuple)
            or not isinstance(self.training_results, tuple)
            or not isinstance(self.checks, tuple)
            or not all(
                isinstance(value, CoverageStateDatasetFreeCaseResult)
                for value in self.case_results
            )
            or not all(
                isinstance(value, CoverageStateDatasetFreeTrainingResult)
                for value in self.training_results
            )
            or not all(
                isinstance(item, tuple)
                and len(item) == 2
                and isinstance(item[0], str)
                and type(item[1]) is bool
                for item in self.checks
            )
        ):
            raise ValueError("dataset-free receipt matrix is incomplete")
        expected_cases = (
            len(COVERAGE_STATE_DATASET_FREE_CASES)
            * len(COVERAGE_STATE_DATASET_FREE_SIZES)
            * len(COVERAGE_STATE_DATASET_FREE_SEEDS)
        )
        expected_training = (
            len(COVERAGE_STATE_DATASET_FREE_SEEDS)
            * len(tuple(CoverageStatePairObjective))
        )
        expected_case_keys = {
            (name, size, seed)
            for name in COVERAGE_STATE_DATASET_FREE_CASES
            for size in COVERAGE_STATE_DATASET_FREE_SIZES
            for seed in COVERAGE_STATE_DATASET_FREE_SEEDS
        }
        actual_case_keys = {
            (value.case_name, value.size, value.seed)
            for value in self.case_results
        }
        expected_training_keys = {
            (seed, objective.value)
            for seed in COVERAGE_STATE_DATASET_FREE_SEEDS
            for objective in CoverageStatePairObjective
        }
        actual_training_keys = {
            (value.seed, value.objective)
            for value in self.training_results
        }
        if (
            len(self.case_results) != expected_cases
            or len(self.training_results) != expected_training
            or actual_case_keys != expected_case_keys
            or actual_training_keys != expected_training_keys
            or not self.checks
            or len({name for name, _ in self.checks}) != len(self.checks)
        ):
            raise ValueError("dataset-free receipt matrix is incomplete")
        if (
            self.D_R_accessed
            or self.D_V_accessed
            or self.D_T_accessed
            or self.performance_claim_supported
        ):
            raise ValueError("dataset-free receipt exceeds its evidence scope")
        recomputed = recompute_coverage_state_dataset_free_checks(
            self.case_results,
            self.training_results,
        )
        if self.checks != recomputed:
            raise ValueError(
                "dataset-free receipt checks do not match recomputed results"
            )

    @property
    def all_pass(self) -> bool:
        self.verify()
        return all(passed for _, passed in self.checks)

    @property
    def status(self) -> str:
        return (
            "DATASET_FREE_GATE_PASS"
            if self.all_pass
            else "DATASET_FREE_GATE_FAIL"
        )

    def canonical_payload(self) -> dict[str, object]:
        self.verify()
        return {
            "schema_version": COVERAGE_STATE_DATASET_FREE_SCHEMA,
            "scope": {
                "case_names": list(COVERAGE_STATE_DATASET_FREE_CASES),
                "sizes": list(COVERAGE_STATE_DATASET_FREE_SIZES),
                "seeds": list(COVERAGE_STATE_DATASET_FREE_SEEDS),
                "geometry_case_count": len(self.case_results),
                "training_updates_per_objective": (
                    COVERAGE_STATE_DATASET_FREE_TRAINING_UPDATES
                ),
                "training_result_count": len(self.training_results),
                "training_role": (
                    "computational_learnability_and_early_gradient_only"
                ),
                "fixture_source": "generated_in_memory_only",
                "selected_representation": "scalar_max",
            },
            "case_results": [
                value.canonical_payload() for value in self.case_results
            ],
            "training_results": [
                value.canonical_payload() for value in self.training_results
            ],
            "checks": {name: passed for name, passed in self.checks},
            "status": self.status,
            "all_pass": self.all_pass,
            "data_access": {
                "D_R_accessed": self.D_R_accessed,
                "D_V_accessed": self.D_V_accessed,
                "D_T_accessed": self.D_T_accessed,
            },
            "performance_claim_supported": self.performance_claim_supported,
            "formal_training_authorized": False,
        }

    @property
    def receipt_fingerprint(self) -> str:
        return stable_fingerprint(self.canonical_payload())


@dataclass(frozen=True)
class _DatasetFreeCase:
    name: str
    feature: Tensor
    occupancy_plus: Tensor
    occupancy_minus: Tensor
    target_plus: Tensor
    target_minus: Tensor
    valid_mask: Tensor
    pair_kind: str | None = None
    optimizer_eligible_pair: bool = False
    expected_scalar_hidden: bool = False

    @property
    def is_pair(self) -> bool:
        return self.pair_kind is not None


def _empty_mask(size: int) -> Tensor:
    return torch.zeros((1, 1, size, size), dtype=torch.bool)


def _put_pixels(mask: Tensor, coordinates: tuple[tuple[int, int], ...]) -> None:
    for row, column in coordinates:
        mask[0, 0, row, column] = True


def _put_box(
    mask: Tensor,
    *,
    row: int,
    column: int,
    height: int,
    width: int,
) -> None:
    mask[0, 0, row : row + height, column : column + width] = True


def _feature(case_name: str, *, size: int, seed: int) -> Tensor:
    feature_size = size // COVERAGE_STATE_DATASET_FREE_STRIDE
    grid = torch.arange(
        feature_size * feature_size,
        dtype=torch.float32,
    ).reshape(1, 1, feature_size, feature_size)
    offset = float(
        (
            seed
            + 17 * COVERAGE_STATE_DATASET_FREE_CASES.index(case_name)
        )
        % 29
    )
    first = ((grid + offset) % 23.0) / 23.0 + 0.05
    second = ((grid * 3.0 + offset + 1.0) % 31.0) / 31.0 + 0.05
    result = torch.cat((first, second), dim=1).contiguous()
    if case_name == "clutter_feature_peak_without_target":
        result = result.clone()
        result[0, 0, feature_size // 2, feature_size // 2] = 100.0
    elif case_name == "low_rms_feature":
        result = result * 1.0e-8
    elif case_name == "high_dynamic_range_feature":
        result = torch.full_like(result, 1.0e-4)
        result[0, 0, feature_size // 2, feature_size // 2] = 1.0e4
        result[0, 1, feature_size // 3, feature_size // 3] = -1.0e4
    return result.to(dtype=torch.float32).contiguous()


def _make_case(case_name: str, *, size: int, seed: int) -> _DatasetFreeCase:
    if case_name not in COVERAGE_STATE_DATASET_FREE_CASES:
        raise ValueError("unknown dataset-free case")
    feature = _feature(case_name, size=size, seed=seed)
    plus = _empty_mask(size)
    minus = _empty_mask(size)
    target_plus = _empty_mask(size)
    target_minus = _empty_mask(size)
    valid = torch.ones_like(plus)
    center = size // 2
    cell_row = (center // COVERAGE_STATE_DATASET_FREE_STRIDE) * (
        COVERAGE_STATE_DATASET_FREE_STRIDE
    )
    cell_column = cell_row
    pair_kind: str | None = None
    optimizer_eligible = False
    expected_hidden = False

    if case_name == "one_pixel_target":
        _put_pixels(target_plus, ((center, center),))
    elif case_name == "three_pixel_compact_target":
        _put_pixels(
            target_plus,
            ((center, center), (center, center + 1), (center + 1, center)),
        )
    elif case_name == "two_disconnected_targets":
        _put_pixels(
            target_plus,
            ((size // 3, size // 3), (2 * size // 3, 2 * size // 3)),
        )
    elif case_name == "target_at_image_edge":
        _put_pixels(target_plus, ((0, 0), (0, 1)))
    elif case_name == "target_near_invalid_barrier":
        valid[:, :, :, center] = False
        _put_pixels(target_plus, ((center, center - 1),))
    elif case_name == "single_false_negative_island":
        _put_box(
            target_plus,
            row=center - 1,
            column=center - 1,
            height=2,
            width=2,
        )
    elif case_name == "multiple_false_islands":
        _put_box(
            target_plus,
            row=size // 4,
            column=size // 4,
            height=2,
            width=2,
        )
        _put_box(
            target_plus,
            row=3 * size // 4,
            column=3 * size // 4,
            height=2,
            width=2,
        )
    elif case_name == "component_null_deletion":
        pair_kind = "component_null"
        optimizer_eligible = True
        _put_box(
            plus,
            row=cell_row,
            column=cell_column,
            height=COVERAGE_STATE_DATASET_FREE_STRIDE,
            width=COVERAGE_STATE_DATASET_FREE_STRIDE,
        )
    elif case_name == "identity_null":
        pair_kind = "identity_null"
        _put_box(
            plus,
            row=cell_row,
            column=cell_column,
            height=2,
            width=2,
        )
        minus = plus.clone()
    elif case_name == "same_feature_cell_multiple_occupancy_phases":
        pair_kind = "component_null"
        expected_hidden = True
        _put_pixels(
            plus,
            (
                (cell_row, cell_column),
                (cell_row, cell_column + 1),
            ),
        )
        _put_pixels(minus, ((cell_row, cell_column),))
    elif case_name == "full_grid_deletion_hidden_by_scalar_projection":
        pair_kind = "component_null"
        expected_hidden = True
        _put_box(
            plus,
            row=cell_row,
            column=cell_column,
            height=COVERAGE_STATE_DATASET_FREE_STRIDE,
            width=COVERAGE_STATE_DATASET_FREE_STRIDE,
        )
        _put_pixels(minus, ((cell_row, cell_column),))
    elif case_name == "clean_pair_with_natural_miss_already_present":
        pair_kind = "clean_positive"
        optimizer_eligible = True
        _put_box(
            plus,
            row=cell_row,
            column=cell_column,
            height=COVERAGE_STATE_DATASET_FREE_STRIDE,
            width=COVERAGE_STATE_DATASET_FREE_STRIDE,
        )
        _put_pixels(target_plus, ((size // 4, size // 4),))
        target_minus = target_plus.clone()
        _put_box(
            target_minus,
            row=cell_row,
            column=cell_column,
            height=COVERAGE_STATE_DATASET_FREE_STRIDE,
            width=COVERAGE_STATE_DATASET_FREE_STRIDE,
        )
    elif case_name in {
        "low_rms_feature",
        "high_dynamic_range_feature",
    }:
        _put_pixels(target_plus, ((center, center),))
    elif case_name in {
        "empty_state",
        "clutter_feature_peak_without_target",
    }:
        pass
    else:
        raise AssertionError("dataset-free case construction is incomplete")

    if pair_kind is None:
        target_minus = target_plus.clone()
        minus = plus.clone()
    return _DatasetFreeCase(
        name=case_name,
        feature=feature,
        occupancy_plus=plus,
        occupancy_minus=minus,
        target_plus=target_plus,
        target_minus=target_minus,
        valid_mask=valid,
        pair_kind=pair_kind,
        optimizer_eligible_pair=optimizer_eligible,
        expected_scalar_hidden=expected_hidden,
    )


def _target_zero_exact(field: Tensor, target: Tensor, valid: Tensor) -> bool:
    return torch.equal((field < 0.0) & valid, target)


def _component_count(value: Tensor) -> int:
    if (
        value.dtype != torch.bool
        or value.device.type != "cpu"
        or tuple(value.shape[:2]) != (1, 1)
    ):
        raise ValueError("component counter requires CPU bool [1,1,H,W]")
    mask = value[0, 0]
    height, width = (int(item) for item in mask.shape)
    visited = torch.zeros_like(mask)
    count = 0
    for row, column in torch.nonzero(mask, as_tuple=False).tolist():
        if bool(visited[row, column]):
            continue
        count += 1
        queue: deque[tuple[int, int]] = deque([(row, column)])
        visited[row, column] = True
        while queue:
            current_row, current_column = queue.popleft()
            for row_offset in (-1, 0, 1):
                for column_offset in (-1, 0, 1):
                    if row_offset == 0 and column_offset == 0:
                        continue
                    next_row = current_row + row_offset
                    next_column = current_column + column_offset
                    if (
                        0 <= next_row < height
                        and 0 <= next_column < width
                        and bool(mask[next_row, next_column])
                        and not bool(visited[next_row, next_column])
                    ):
                        visited[next_row, next_column] = True
                        queue.append((next_row, next_column))
    return count


def _new_component_count(plus: Tensor, minus: Tensor) -> int:
    """Count minus components with no overlap with a plus component."""

    if plus.shape != minus.shape or plus.dtype != torch.bool:
        raise ValueError("completion endpoints must be aligned bool masks")
    mask = minus[0, 0]
    plus_mask = plus[0, 0]
    height, width = (int(item) for item in mask.shape)
    visited = torch.zeros_like(mask)
    new_count = 0
    for row, column in torch.nonzero(mask, as_tuple=False).tolist():
        if bool(visited[row, column]):
            continue
        overlaps_plus = False
        queue: deque[tuple[int, int]] = deque([(row, column)])
        visited[row, column] = True
        while queue:
            current_row, current_column = queue.popleft()
            overlaps_plus = overlaps_plus or bool(
                plus_mask[current_row, current_column]
            )
            for row_offset in (-1, 0, 1):
                for column_offset in (-1, 0, 1):
                    if row_offset == 0 and column_offset == 0:
                        continue
                    next_row = current_row + row_offset
                    next_column = current_column + column_offset
                    if (
                        0 <= next_row < height
                        and 0 <= next_column < width
                        and bool(mask[next_row, next_column])
                        and not bool(visited[next_row, next_column])
                    ):
                        visited[next_row, next_column] = True
                        queue.append((next_row, next_column))
        if not overlaps_plus:
            new_count += 1
    return new_count


def _hard_union_exact(
    model: CURELiteCoverageStateLevelSet,
    feature: Tensor,
    occupancy: Tensor,
) -> bool:
    completion = model.predict_completion(feature, occupancy)
    union = model.predict_union(feature, occupancy)
    return (
        torch.equal(union, occupancy | completion)
        and not bool(torch.any(completion & occupancy))
    )


def _evaluate_case(
    case: _DatasetFreeCase,
    *,
    model: CURELiteCoverageStateLevelSet,
    config: CoverageStateSobolevConfig,
    size: int,
    seed: int,
) -> CoverageStateDatasetFreeCaseResult:
    field_plus_target = truncated_signed_distance_field(
        case.target_plus,
        case.valid_mask,
        radius=config.truncation_radius,
    )
    field_minus_target = truncated_signed_distance_field(
        case.target_minus,
        case.valid_mask,
        radius=config.truncation_radius,
    )
    target_finite = bool(
        torch.stack(
            (
                torch.isfinite(field_plus_target).all(),
                torch.isfinite(field_minus_target).all(),
                torch.isfinite(normalize_cslf_feature(case.feature)).all(),
            )
        ).all()
    )
    zero_exact = _target_zero_exact(
        field_plus_target,
        case.target_plus,
        case.valid_mask,
    ) and _target_zero_exact(
        field_minus_target,
        case.target_minus,
        case.valid_mask,
    )
    with torch.no_grad():
        feature = (
            torch.cat((case.feature, case.feature), dim=0)
            if case.is_pair
            else case.feature
        )
        occupancy = (
            torch.cat(
                (case.occupancy_plus, case.occupancy_minus),
                dim=0,
            )
            if case.is_pair
            else case.occupancy_plus
        )
        predicted = model(feature, occupancy)
        predicted_plus = predicted[:1]
        predicted_minus = predicted[1:] if case.is_pair else predicted[:1]
        model_finite = bool(torch.isfinite(predicted).all())
        predicted_completion = (
            (predicted_plus < 0.0)
            & ~case.occupancy_plus
            & case.valid_mask
        )
        hard_union = _hard_union_exact(
            model,
            case.feature,
            case.occupancy_plus,
        )

    scalar_visible: bool | None = None
    phase_visible: bool | None = None
    phase_roundtrip: bool | None = None
    response_pixels = 0
    outside_scalar_pixels = 0
    outside_phase_pixels = 0
    identity_exact: bool | None = None
    hidden_exact: bool | None = None
    component_new_pixels: int | None = None
    component_new_components: int | None = None
    if case.is_pair:
        feature_size = tuple(int(value) for value in case.feature.shape[-2:])
        scalar_plus = occupancy_to_scalar_grid(
            case.occupancy_plus,
            feature_size=feature_size,
        )
        scalar_minus = occupancy_to_scalar_grid(
            case.occupancy_minus,
            feature_size=feature_size,
        )
        phase_plus = occupancy_to_phase_grid(
            case.occupancy_plus,
            stride=COVERAGE_STATE_DATASET_FREE_STRIDE,
        )
        phase_minus = occupancy_to_phase_grid(
            case.occupancy_minus,
            stride=COVERAGE_STATE_DATASET_FREE_STRIDE,
        )
        scalar_changes = changed_feature_cells(
            scalar_plus,
            scalar_minus,
        )
        phase_changes = changed_feature_cells(phase_plus, phase_minus)
        scalar_visible = bool(torch.any(scalar_changes))
        phase_visible = bool(torch.any(phase_changes))
        phase_roundtrip = (
            torch.equal(
                torch.nn.functional.pixel_shuffle(
                    phase_plus.to(torch.float32),
                    COVERAGE_STATE_DATASET_FREE_STRIDE,
                ).to(torch.bool),
                case.occupancy_plus,
            )
            and torch.equal(
                torch.nn.functional.pixel_shuffle(
                    phase_minus.to(torch.float32),
                    COVERAGE_STATE_DATASET_FREE_STRIDE,
                ).to(torch.bool),
                case.occupancy_minus,
            )
        )
        response = target_response_support(
            field_plus_target,
            field_minus_target,
            case.valid_mask,
        )
        response_pixels = int(torch.count_nonzero(response))
        receptive = structural_output_support(
            scalar_changes,
            stride=COVERAGE_STATE_DATASET_FREE_STRIDE,
        )
        phase_receptive = structural_output_support(
            phase_changes,
            stride=COVERAGE_STATE_DATASET_FREE_STRIDE,
        )
        outside_scalar_pixels = int(
            torch.count_nonzero(response & ~receptive)
        )
        outside_phase_pixels = int(
            torch.count_nonzero(response & ~phase_receptive)
        )
        if case.pair_kind == "identity_null":
            identity_exact = torch.equal(predicted_plus, predicted_minus)
        if case.expected_scalar_hidden:
            hidden_exact = torch.equal(predicted_plus, predicted_minus)
        if case.pair_kind == "component_null":
            completion_plus = (
                (predicted_plus < 0.0)
                & ~case.occupancy_plus
                & case.valid_mask
            )
            completion_minus = (
                (predicted_minus < 0.0)
                & ~case.occupancy_minus
                & case.valid_mask
            )
            removed = case.occupancy_plus & ~case.occupancy_minus
            component_new_pixels = int(
                torch.count_nonzero(
                    completion_minus & ~completion_plus & removed
                )
            )
            component_new_components = _new_component_count(
                completion_plus,
                completion_minus,
            )

    return CoverageStateDatasetFreeCaseResult(
        case_name=case.name,
        size=size,
        seed=seed,
        state_type="pair" if case.is_pair else "absolute",
        pair_kind=case.pair_kind,
        optimizer_eligible_pair=case.optimizer_eligible_pair,
        expected_scalar_hidden=case.expected_scalar_hidden,
        target_pixels_plus=int(torch.count_nonzero(case.target_plus)),
        target_pixels_minus=int(torch.count_nonzero(case.target_minus)),
        target_zero_level_exact=zero_exact,
        target_fields_finite=target_finite,
        model_fields_finite=model_finite,
        hard_union_exact=hard_union,
        scalar_visible=scalar_visible,
        phase_visible=phase_visible,
        phase_roundtrip_exact=phase_roundtrip,
        target_response_pixels=response_pixels,
        target_response_outside_scalar_rf_pixels=outside_scalar_pixels,
        target_response_outside_phase_rf_pixels=outside_phase_pixels,
        predicted_negative_pixels=int(
            torch.count_nonzero(predicted_completion)
        ),
        predicted_negative_components=_component_count(
            predicted_completion
        ),
        identity_field_exact=identity_exact,
        hidden_component_field_exact=hidden_exact,
        component_new_negative_pixels=component_new_pixels,
        component_new_negative_components=component_new_components,
    )


def _stack_absolute(
    values: tuple[CoverageStateAbsoluteTargets, ...],
) -> CoverageStateAbsoluteTargets:
    result = CoverageStateAbsoluteTargets(
        target_field=torch.cat(
            tuple(value.target_field for value in values),
            dim=0,
        ).contiguous(),
        integration_measure=torch.cat(
            tuple(value.integration_measure for value in values),
            dim=0,
        ).contiguous(),
        field_valid_mask=torch.cat(
            tuple(value.field_valid_mask for value in values),
            dim=0,
        ).contiguous(),
        loss_valid_mask=torch.cat(
            tuple(value.loss_valid_mask for value in values),
            dim=0,
        ).contiguous(),
        focus_support=torch.cat(
            tuple(value.focus_support for value in values),
            dim=0,
        ).contiguous(),
        focus_support_field=torch.cat(
            tuple(value.focus_support_field for value in values),
            dim=0,
        ).contiguous(),
    )
    result.validate()
    return result


def _stack_pair(
    values: tuple[CoverageStatePairTargets, ...],
) -> CoverageStatePairTargets:
    result = CoverageStatePairTargets(
        target_field_plus=torch.cat(
            tuple(value.target_field_plus for value in values),
            dim=0,
        ).contiguous(),
        target_field_minus=torch.cat(
            tuple(value.target_field_minus for value in values),
            dim=0,
        ).contiguous(),
        focus_support=torch.cat(
            tuple(value.focus_support for value in values),
            dim=0,
        ).contiguous(),
        focus_support_field=torch.cat(
            tuple(value.focus_support_field for value in values),
            dim=0,
        ).contiguous(),
        integration_measure=torch.cat(
            tuple(value.integration_measure for value in values),
            dim=0,
        ).contiguous(),
        valid_mask=torch.cat(
            tuple(value.valid_mask for value in values),
            dim=0,
        ).contiguous(),
    )
    result.validate()
    return result


def _training_batch(seed: int) -> CoverageStateFusedBatch:
    size = 64
    config = CoverageStateSobolevConfig(
        truncation_radius=COVERAGE_STATE_DATASET_FREE_STRIDE
    )
    miss_cases = (
        "one_pixel_target",
        "three_pixel_compact_target",
        "two_disconnected_targets",
        "target_at_image_edge",
    )
    no_cases = (
        "empty_state",
        "clutter_feature_peak_without_target",
        "low_rms_feature",
        "high_dynamic_range_feature",
    )
    miss = tuple(
        _make_case(name, size=size, seed=seed) for name in miss_cases
    )
    no_miss = tuple(
        replace(
            _make_case(name, size=size, seed=seed),
            target_plus=_empty_mask(size),
            target_minus=_empty_mask(size),
        )
        for name in no_cases
    )
    if (
        any(not bool(torch.any(value.target_plus)) for value in miss)
        or any(bool(torch.any(value.target_plus)) for value in no_miss)
    ):
        raise AssertionError("dataset-free natural roles are not disjoint")
    miss_targets = tuple(
        prepare_coverage_state_focused_absolute_targets(
            value.target_plus,
            value.valid_mask,
            value.valid_mask & ~value.occupancy_plus,
            config=config,
        )
        for value in miss
    )
    no_targets = tuple(
        prepare_coverage_state_focused_absolute_targets(
            value.target_plus,
            value.valid_mask,
            value.valid_mask & ~value.occupancy_plus,
            config=config,
        )
        for value in no_miss
    )
    clean = _make_case(
        "clean_pair_with_natural_miss_already_present",
        size=size,
        seed=seed,
    )
    component = _make_case(
        "component_null_deletion",
        size=size,
        seed=seed,
    )
    pair_values = (clean, component)
    joint = tuple(
        prepare_coverage_state_pair_targets(
            value.occupancy_plus,
            value.occupancy_minus,
            value.target_plus,
            value.target_minus,
            value.valid_mask,
            config=config,
        )
        for value in pair_values
    )
    absolute_plus = tuple(
        prepare_coverage_state_focused_absolute_targets(
            value.target_plus,
            value.valid_mask,
            value.valid_mask & ~value.occupancy_plus,
            config=config,
        )
        for value in pair_values
    )
    absolute_minus = tuple(
        prepare_coverage_state_focused_absolute_targets(
            value.target_minus,
            value.valid_mask,
            value.valid_mask & ~value.occupancy_minus,
            config=config,
        )
        for value in pair_values
    )
    result = CoverageStateFusedBatch(
        factual_miss=CoverageStateNaturalTrainBatch(
            feature=torch.cat(tuple(value.feature for value in miss), dim=0),
            occupancy=torch.cat(
                tuple(value.occupancy_plus for value in miss),
                dim=0,
            ),
            targets=_stack_absolute(miss_targets),
            record_ids=tuple(f"df-miss-{seed}-{index}" for index in range(4)),
            sample_ids=tuple(
                f"df-miss-source-{seed}-{index}" for index in range(4)
            ),
            actual_input_fingerprints=tuple(
                stable_fingerprint(
                    {"kind": "miss", "seed": seed, "index": index}
                )
                for index in range(4)
            ),
            state_kind="factual_miss",
        ),
        factual_no_miss=CoverageStateNaturalTrainBatch(
            feature=torch.cat(
                tuple(value.feature for value in no_miss),
                dim=0,
            ),
            occupancy=torch.cat(
                tuple(value.occupancy_plus for value in no_miss),
                dim=0,
            ),
            targets=_stack_absolute(no_targets),
            record_ids=tuple(f"df-no-{seed}-{index}" for index in range(4)),
            sample_ids=tuple(
                f"df-no-source-{seed}-{index}" for index in range(4)
            ),
            actual_input_fingerprints=tuple(
                stable_fingerprint(
                    {"kind": "no_miss", "seed": seed, "index": index}
                )
                for index in range(4)
            ),
            state_kind="factual_no_miss",
        ),
        pairs=CoverageStatePairTrainBatch(
            feature=torch.cat(
                tuple(value.feature for value in pair_values),
                dim=0,
            ),
            occupancy_plus=torch.cat(
                tuple(value.occupancy_plus for value in pair_values),
                dim=0,
            ),
            occupancy_minus=torch.cat(
                tuple(value.occupancy_minus for value in pair_values),
                dim=0,
            ),
            joint_targets=_stack_pair(joint),
            absolute_targets_plus=_stack_absolute(absolute_plus),
            absolute_targets_minus=_stack_absolute(absolute_minus),
            pair_ids=(
                f"df-clean-{seed}",
                f"df-component-{seed}",
            ),
            pair_kinds=("clean_positive", "component_null"),
            sample_ids=(
                f"df-clean-source-{seed}",
                f"df-component-source-{seed}",
            ),
            actual_input_plus_fingerprints=(
                stable_fingerprint(
                    {"kind": "clean_plus", "seed": seed}
                ),
                stable_fingerprint(
                    {"kind": "component_plus", "seed": seed}
                ),
            ),
            actual_input_minus_fingerprints=(
                stable_fingerprint(
                    {"kind": "clean_minus", "seed": seed}
                ),
                stable_fingerprint(
                    {"kind": "component_minus", "seed": seed}
                ),
            ),
        ),
    )
    result.validate()
    return result


def _post_training_diagnostics(
    model: CURELiteCoverageStateLevelSet,
    *,
    seed: int,
) -> dict[str, object]:
    size = 64
    identity = _make_case("identity_null", size=size, seed=seed)
    hidden = _make_case(
        "full_grid_deletion_hidden_by_scalar_projection",
        size=size,
        seed=seed,
    )
    component = _make_case(
        "component_null_deletion",
        size=size,
        seed=seed,
    )
    empty = _make_case("empty_state", size=size, seed=seed)
    with torch.no_grad():
        identity_field = model(
            torch.cat((identity.feature, identity.feature), dim=0),
            torch.cat(
                (identity.occupancy_plus, identity.occupancy_minus),
                dim=0,
            ),
        )
        hidden_field = model(
            torch.cat((hidden.feature, hidden.feature), dim=0),
            torch.cat(
                (hidden.occupancy_plus, hidden.occupancy_minus),
                dim=0,
            ),
        )
        component_field = model(
            torch.cat((component.feature, component.feature), dim=0),
            torch.cat(
                (
                    component.occupancy_plus,
                    component.occupancy_minus,
                ),
                dim=0,
            ),
        )
        component_plus = (
            (component_field[:1] < 0.0)
            & ~component.occupancy_plus
            & component.valid_mask
        )
        component_minus = (
            (component_field[1:] < 0.0)
            & ~component.occupancy_minus
            & component.valid_mask
        )
        removed = component.occupancy_plus & ~component.occupancy_minus
        empty_field = model(empty.feature, empty.occupancy_plus)
        empty_completion = (
            (empty_field < 0.0)
            & ~empty.occupancy_plus
            & empty.valid_mask
        )
        hard_union = _hard_union_exact(
            model,
            empty.feature,
            empty.occupancy_plus,
        )
    return {
        "diagnostic_fields_finite": bool(
            torch.isfinite(identity_field).all()
            and torch.isfinite(hidden_field).all()
            and torch.isfinite(component_field).all()
            and torch.isfinite(empty_field).all()
        ),
        "identity_field_exact": torch.equal(
            identity_field[:1],
            identity_field[1:],
        ),
        "hidden_component_field_exact": torch.equal(
            hidden_field[:1],
            hidden_field[1:],
        ),
        "component_new_negative_pixels": int(
            torch.count_nonzero(
                component_minus & ~component_plus & removed
            )
        ),
        "component_new_negative_components": _new_component_count(
            component_plus,
            component_minus,
        ),
        "empty_negative_pixels": int(
            torch.count_nonzero(empty_completion)
        ),
        "empty_negative_components": _component_count(empty_completion),
        "hard_union_exact": hard_union,
    }


def _run_training_matrix(
    seed: int,
) -> tuple[CoverageStateDatasetFreeTrainingResult, ...]:
    model_config = CoverageStateLevelSetConfig(
        feature_channels=COVERAGE_STATE_DATASET_FREE_FEATURE_CHANNELS,
        feature_stride=COVERAGE_STATE_DATASET_FREE_STRIDE,
        width=COVERAGE_STATE_DATASET_FREE_WIDTH,
    )
    sobolev = CoverageStateSobolevConfig(
        truncation_radius=COVERAGE_STATE_DATASET_FREE_STRIDE
    )
    torch.manual_seed(seed)
    initial_model = CURELiteCoverageStateLevelSet(model_config)
    initial_fingerprint = coverage_state_model_fingerprint(initial_model)
    initial_state = deepcopy(initial_model.state_dict())
    batch = _training_batch(seed)
    results: list[CoverageStateDatasetFreeTrainingResult] = []
    for objective in CoverageStatePairObjective:
        model = CURELiteCoverageStateLevelSet(model_config)
        model.load_state_dict(initial_state, strict=True)
        optimizer = torch.optim.Adam(model.parameters(), lr=1.0e-3)
        first_nonzero: dict[str, int] = {}
        losses_finite = True
        forward_calls = 0
        backward_calls = 0
        optimizer_steps = 0
        logical_states = 0
        selection_fingerprints: set[str] = set()
        for update in range(COVERAGE_STATE_DATASET_FREE_TRAINING_UPDATES):
            logs = coverage_state_fused_train_step(
                model,
                optimizer,
                batch,
                config=sobolev,
                pair_objective=objective,
                audit=False,
                track_nonzero_gradients=True,
            )
            losses_finite = losses_finite and all(
                isfinite(float(logs[name]))
                for name in (
                    "factual_miss/loss",
                    "factual_no_miss/loss",
                    "pair/loss",
                    "total",
                    "gradient_l2_norm",
                )
            )
            for name in filter(
                None,
                str(logs["nonzero_gradient_parameters"]).split(","),
            ):
                first_nonzero.setdefault(name, update)
            forward_calls += int(logs["model_forward_calls"])
            backward_calls += int(logs["backward_calls"])
            optimizer_steps += int(logs["optimizer_steps"])
            logical_states += int(logs["logical_states"])
            selection_fingerprints.add(
                str(logs["selection_fingerprint"])
            )
        final_fingerprint = coverage_state_model_fingerprint(model)
        diagnostics = _post_training_diagnostics(model, seed=seed)
        if len(selection_fingerprints) != 1:
            raise AssertionError("dataset-free selection changed across updates")
        results.append(
            CoverageStateDatasetFreeTrainingResult(
                seed=seed,
                objective=objective.value,
                updates=COVERAGE_STATE_DATASET_FREE_TRAINING_UPDATES,
                forward_calls=forward_calls,
                backward_calls=backward_calls,
                optimizer_steps=optimizer_steps,
                logical_state_evaluations=logical_states,
                initial_model_fingerprint=initial_fingerprint,
                final_model_fingerprint=final_fingerprint,
                selection_fingerprint=next(iter(selection_fingerprints)),
                first_nonzero_gradient_update=tuple(
                    sorted(first_nonzero.items())
                ),
                factual_miss_target_pixels=int(
                    torch.count_nonzero(
                        batch.factual_miss.targets.target_field < 0.0
                    )
                ),
                factual_no_miss_target_pixels=int(
                    torch.count_nonzero(
                        batch.factual_no_miss.targets.target_field < 0.0
                    )
                ),
                losses_finite=losses_finite,
                parameters_changed=(
                    final_fingerprint != initial_fingerprint
                ),
                diagnostic_fields_finite=bool(
                    diagnostics["diagnostic_fields_finite"]
                ),
                identity_field_exact=bool(
                    diagnostics["identity_field_exact"]
                ),
                hidden_component_field_exact=bool(
                    diagnostics["hidden_component_field_exact"]
                ),
                component_new_negative_pixels=int(
                    diagnostics["component_new_negative_pixels"]
                ),
                component_new_negative_components=int(
                    diagnostics["component_new_negative_components"]
                ),
                empty_negative_pixels=int(
                    diagnostics["empty_negative_pixels"]
                ),
                empty_negative_components=int(
                    diagnostics["empty_negative_components"]
                ),
                hard_union_exact=bool(diagnostics["hard_union_exact"]),
            )
        )
    return tuple(results)


def recompute_coverage_state_dataset_free_checks(
    case_results: tuple[CoverageStateDatasetFreeCaseResult, ...],
    training_results: tuple[CoverageStateDatasetFreeTrainingResult, ...],
) -> tuple[tuple[str, bool], ...]:
    """Recompute the complete frozen gate from its evidence rows.

    This function is the sole implementation of the dataset-free decision
    rule.  Caller-supplied check booleans are never treated as authoritative.
    """

    cases = tuple(case_results)
    training_results = tuple(training_results)
    optimizer_pairs = tuple(
        value for value in cases if value.optimizer_eligible_pair
    )
    hidden_pairs = tuple(
        value for value in cases if value.expected_scalar_hidden
    )
    identity_pairs = tuple(
        value for value in cases if value.pair_kind == "identity_null"
    )
    component_pairs = tuple(
        value for value in cases if value.pair_kind == "component_null"
    )
    empty_states = tuple(
        value for value in cases if value.case_name == "empty_state"
    )
    expected_case_keys = {
        (name, size, seed)
        for name in COVERAGE_STATE_DATASET_FREE_CASES
        for size in COVERAGE_STATE_DATASET_FREE_SIZES
        for seed in COVERAGE_STATE_DATASET_FREE_SEEDS
    }
    actual_case_keys = {
        (value.case_name, value.size, value.seed) for value in cases
    }
    with torch.random.fork_rng(devices=[]):
        parameter_names = {
            name
            for name, _ in CURELiteCoverageStateLevelSet(
                CoverageStateLevelSetConfig(
                    feature_channels=(
                        COVERAGE_STATE_DATASET_FREE_FEATURE_CHANNELS
                    ),
                    feature_stride=COVERAGE_STATE_DATASET_FREE_STRIDE,
                    width=COVERAGE_STATE_DATASET_FREE_WIDTH,
                )
            ).named_parameters()
        }
    return (
        ("geometry_matrix_complete", actual_case_keys == expected_case_keys),
        (
            "geometry_and_model_fields_finite",
            all(
                value.target_fields_finite and value.model_fields_finite
                for value in cases
            )
            and all(
                value.diagnostic_fields_finite
                for value in training_results
            ),
        ),
        (
            "target_zero_level_exact",
            all(value.target_zero_level_exact for value in cases),
        ),
        (
            "hard_union_exact",
            all(value.hard_union_exact for value in cases)
            and all(value.hard_union_exact for value in training_results),
        ),
        (
            "identity_null_exact",
            all(value.identity_field_exact is True for value in identity_pairs)
            and all(value.identity_field_exact for value in training_results),
        ),
        (
            "scalar_hidden_component_exact",
            bool(hidden_pairs)
            and all(
                value.scalar_visible is False
                and value.phase_visible is True
                and value.hidden_component_field_exact is True
                for value in hidden_pairs
            )
            and all(
                value.hidden_component_field_exact
                for value in training_results
            ),
        ),
        (
            "component_null_no_new_negative_island",
            all(
                value.component_new_negative_pixels == 0
                and value.component_new_negative_components == 0
                for value in component_pairs
            )
            and all(
                value.component_new_negative_pixels == 0
                and value.component_new_negative_components == 0
                for value in training_results
            ),
        ),
        (
            "empty_state_negative_component_count_zero",
            bool(empty_states)
            and all(
                value.predicted_negative_pixels == 0
                and value.predicted_negative_components == 0
                for value in empty_states
            )
            and all(
                value.empty_negative_pixels == 0
                and value.empty_negative_components == 0
                for value in training_results
            ),
        ),
        (
            "selected_scalar_representation_has_no_hidden_optimizer_pair",
            bool(optimizer_pairs)
            and all(value.scalar_visible is True for value in optimizer_pairs),
        ),
        (
            "phase_roundtrip_exact",
            all(
                value.phase_roundtrip_exact is True
                for value in cases
                if value.state_type == "pair"
            ),
        ),
        (
            "target_response_inside_selected_scalar_rf",
            all(
                value.target_response_outside_scalar_rf_pixels == 0
                for value in cases
            ),
        ),
        (
            "target_response_inside_phase_rf",
            all(
                value.target_response_outside_phase_rf_pixels == 0
                for value in cases
            ),
        ),
        (
            "three_objectives_computationally_learnable",
            all(
                value.losses_finite
                and value.parameters_changed
                and value.factual_miss_target_pixels > 0
                and value.factual_no_miss_target_pixels == 0
                for value in training_results
            ),
        ),
        (
            "early_gradient_latency",
            all(
                set(dict(value.first_nonzero_gradient_update))
                == parameter_names
                and dict(value.first_nonzero_gradient_update)[
                    "phase_projection.weight"
                ]
                == 0
                and dict(value.first_nonzero_gradient_update)[
                    "phase_projection.bias"
                ]
                == 0
                and dict(value.first_nonzero_gradient_update)[
                    "input_projection.weight"
                ]
                <= 2
                and dict(value.first_nonzero_gradient_update)[
                    "spatial_mixing.weight"
                ]
                <= 2
                for value in training_results
            ),
        ),
        (
            "training_compute_ledger_exact",
            all(
                value.updates
                == COVERAGE_STATE_DATASET_FREE_TRAINING_UPDATES
                and value.forward_calls
                == COVERAGE_STATE_DATASET_FREE_TRAINING_UPDATES
                and value.backward_calls
                == COVERAGE_STATE_DATASET_FREE_TRAINING_UPDATES
                and value.optimizer_steps
                == COVERAGE_STATE_DATASET_FREE_TRAINING_UPDATES
                and value.logical_state_evaluations
                == 12 * COVERAGE_STATE_DATASET_FREE_TRAINING_UPDATES
                for value in training_results
            ),
        ),
        (
            "matched_objective_fairness",
            all(
                len(
                    {
                        value.initial_model_fingerprint
                        for value in training_results
                        if value.seed == seed
                    }
                )
                == 1
                and len(
                    {
                        value.selection_fingerprint
                        for value in training_results
                        if value.seed == seed
                    }
                )
                == 1
                for seed in COVERAGE_STATE_DATASET_FREE_SEEDS
            ),
        ),
        (
            "no_dataset_split_access",
            True,
        ),
    )


def run_coverage_state_dataset_free_gate() -> CoverageStateDatasetFreeReceipt:
    """Run the frozen expanded dataset-free gate entirely on CPU."""

    model_config = CoverageStateLevelSetConfig(
        feature_channels=COVERAGE_STATE_DATASET_FREE_FEATURE_CHANNELS,
        feature_stride=COVERAGE_STATE_DATASET_FREE_STRIDE,
        width=COVERAGE_STATE_DATASET_FREE_WIDTH,
    )
    sobolev = CoverageStateSobolevConfig(
        truncation_radius=COVERAGE_STATE_DATASET_FREE_STRIDE
    )
    case_results: list[CoverageStateDatasetFreeCaseResult] = []
    for seed in COVERAGE_STATE_DATASET_FREE_SEEDS:
        torch.manual_seed(seed)
        model = CURELiteCoverageStateLevelSet(model_config)
        model.eval()
        for size in COVERAGE_STATE_DATASET_FREE_SIZES:
            for case_name in COVERAGE_STATE_DATASET_FREE_CASES:
                case_results.append(
                    _evaluate_case(
                        _make_case(case_name, size=size, seed=seed),
                        model=model,
                        config=sobolev,
                        size=size,
                        seed=seed,
                    )
                )
    training_results = tuple(
        result
        for seed in COVERAGE_STATE_DATASET_FREE_SEEDS
        for result in _run_training_matrix(seed)
    )
    cases = tuple(case_results)
    checks = recompute_coverage_state_dataset_free_checks(
        cases,
        training_results,
    )
    return CoverageStateDatasetFreeReceipt(
        case_results=cases,
        training_results=training_results,
        checks=checks,
    )


__all__ = [
    "COVERAGE_STATE_DATASET_FREE_CASES",
    "COVERAGE_STATE_DATASET_FREE_SCHEMA",
    "COVERAGE_STATE_DATASET_FREE_SEEDS",
    "COVERAGE_STATE_DATASET_FREE_SIZES",
    "COVERAGE_STATE_DATASET_FREE_TRAINING_UPDATES",
    "CoverageStateDatasetFreeCaseResult",
    "CoverageStateDatasetFreeReceipt",
    "CoverageStateDatasetFreeTrainingResult",
    "recompute_coverage_state_dataset_free_checks",
    "run_coverage_state_dataset_free_gate",
]
